package Darman.part1;

public class Exo1_01 {
	public static void main(String[] args) {
		int A=1;
		int B= A+3;
		A=3;
		System.out.println("la variable A est : " +A + ".\nLa variable B est: "+B);
	}
}

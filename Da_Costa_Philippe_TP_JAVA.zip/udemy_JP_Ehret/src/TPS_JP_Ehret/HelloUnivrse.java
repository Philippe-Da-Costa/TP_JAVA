package TPS_JP_Ehret;

public class HelloUnivrse {

	public static void main(String[] args) {
		System.out.println("Hello universe !");

	}

}

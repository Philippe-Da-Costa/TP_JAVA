package Darman.part2;

public class Exo2_01 {
	public static void main(String[] args) {
		double val = 231;
		double Double=val*2;
		System.out.println(val+"\n"+ Double);
	}

}

package Darman.part1;

public class Exo1_08 {
	public static void main(String[] args) {
		String A="423";
		String B="12";
		String C=A+B;
		System.out.println(C);
	}
}

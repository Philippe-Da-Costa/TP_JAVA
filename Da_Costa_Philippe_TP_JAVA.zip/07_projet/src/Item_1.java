

public class Item_1 {

	public static void main(String[] args) {
		for (short i=0;i<=40000;i++) {
			System.out.println(i);
			
		}

	}

}

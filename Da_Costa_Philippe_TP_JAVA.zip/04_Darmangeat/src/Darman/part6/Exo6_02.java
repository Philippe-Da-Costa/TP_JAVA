package Darman.part6;

import java.util.Arrays;

public class Exo6_02 {
 public static void main(String[] args) {
	char [] tab = {'ā','e','i','o','u','y'};
	//FOREACH
	for(char voyelle:tab)
	System.out.print(voyelle+" ");
}
}

package Darman.part7;

public class Exo7_01 {

	public static void main(String[] args) {
		

	}

}

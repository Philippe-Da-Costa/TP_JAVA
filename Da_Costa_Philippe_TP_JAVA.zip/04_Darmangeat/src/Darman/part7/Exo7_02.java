package Darman.part7;

public class Exo7_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package lesTableaux1;

public class Tableaux00 {
	/*
	////////////         Syntaxes       ////////////
	int[]  tab, tab2, tab3 ;  on peux creer plusieurs tableaux .
    int tab[] ,tab2 ;   tab  est un tableau et tab2 est un nom de variable.
    
    /////////////////////    RESUME     ///////////
     int tab[];
    int tab[]  / int[] tab;
    int tab [] ={1,2,,3};
    int tab [] = new int[3];
    int tab [] = new int[] {1,2,3};
	*/
	
	
	public static void main(String[] args) {
	
		int[] tab = {1,2,3}; //ici je declare les donnees de mon tableau.
		int[] tab0= new int[] {1,2,3}; //ici je declare les donnees de mon tableau v2.
		int[] tab1 = new int [3];// ici je reserve 3 emplacement a mon tab1
	}

}

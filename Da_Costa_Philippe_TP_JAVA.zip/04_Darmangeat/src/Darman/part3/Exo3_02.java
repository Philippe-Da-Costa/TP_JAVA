package Darman.part3;
import java.util.Scanner;
public class Exo3_02 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	     int nb1, nb2;
	     
	    
	     
	     System.out.println("Saisir un premier nombre SVP");
	     nb1 = sc.nextInt();
	     System.out.println("Saisir un second nombre SVP");
	     nb2 = sc.nextInt();
	     
	     if(nb1<0 | nb2<0) { 
	    	 System.out.println("le produit est negatif");}else {
	    		 System.out.println("le produit est positif") ;
	    	 }
	     }
	     
	    
	     }
	


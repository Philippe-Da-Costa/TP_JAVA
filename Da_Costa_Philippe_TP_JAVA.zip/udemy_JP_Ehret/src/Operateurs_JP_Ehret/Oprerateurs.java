package Operateurs_JP_Ehret;

public class Oprerateurs {

	public static void main(String[] args) {
		int resultat=5+2;
		System.out.println("addition : "+resultat);
		resultat=5-2;
		System.out.println("soustraction : "+resultat);
		resultat=5*2;
		System.out.println("amultiplication : "+resultat);
		resultat=5/2;
		System.out.println("division !entier! : "+resultat);
		float result=5f/2;
		System.out.println("division float : "+result);
		result=5f/2+3;
		System.out.println("division et add: "+result);
		result=5f/(2+3);
		System.out.println("division et add: "+result);
		resultat=5%2;
		System.out.println("modulo: "+resultat);

	}

}

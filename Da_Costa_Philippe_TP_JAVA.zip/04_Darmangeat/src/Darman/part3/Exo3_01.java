package Darman.part3;
import java.util.Scanner;
public class Exo3_01 {
public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
     int nb;
     System.out.println("Saisir un nombre SVP");
     nb = sc.nextInt();
     if(nb<0) {
    	 System.out.println("le nombre est negatif");}
    	 else {
    		 System.out.println("Le nombre est positif");
    	 };
     
     };
}

